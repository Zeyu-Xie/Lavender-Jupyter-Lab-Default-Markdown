# Lavender-Jupyter-Lab-Default-Markdown
A pip package to set the default type of Jupyter Lab cells to markdown
